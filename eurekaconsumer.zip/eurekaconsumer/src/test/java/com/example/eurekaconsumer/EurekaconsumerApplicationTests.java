package com.example.eurekaconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
