package com.example.eurekaprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaproviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
